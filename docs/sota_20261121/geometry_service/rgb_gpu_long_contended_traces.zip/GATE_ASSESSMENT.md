# Evaluación post-run

Nota añadida después del sellado, fuera de `MANIFEST.json`, vinculada a `RESULTS.json` SHA-256
`44b6ca830fbc5b262b06ff18fe2b7c2b1cc3542ddd440e1c00334d8429dfa2e4`.

`capacity_decision=FAIL`; `effective_decision=INVALIDATED`. El directorio conserva el nombre
histórico `rgb_gpu_long_dedicated`, pero PID 37868 entró antes de la primera celda y coexistió
con el runner PID 15436. Por tanto sólo es una medición bajo carga concurrente, no capacidad
dedicada: 24.000 ofertas, 1.886 válidas, 22.114 drops, 0 antes de 20 ms y paridad exacta en
3.236/3.236 predicciones producidas.

No se deriva una comparación CPU–GPU: no se demostró identidad oferta por oferta entre ambas
poblaciones y esta campaña estuvo sometida a carga concurrente.
