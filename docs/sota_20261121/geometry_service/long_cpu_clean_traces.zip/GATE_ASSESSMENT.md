# Evaluación post-run del gate

Esta nota se añadió después del sellado y no forma parte de `MANIFEST.sha256`. Se vincula a
`RESULTS.json` SHA-256
`ad77962aba3599e2398472a5b67b8e90a7a5a80dd7f94104cd66d89758ed55a8`.

`strict_service_gate = FAIL`: 7/8 celdas cumplen; 24.000 ofertas, 23.995 respuestas completas
válidas, 23.992 antes de 20 ms y 5 drops. La condición
`supplied_050ms__objects_04__queue_02` tuvo 5 drops, 2.992/3.000 antes de 20 ms y máximo
154,8274 ms. No se afirma capacidad garantizada a 50 Hz para toda la matriz.

La paridad pasa para 59.980/59.980 predicciones producidas, con error absoluto máximo 0. Las
20 predicciones ausentes corresponden a las cinco ofertas de cuatro objetos descartadas y no
se compararon; la paridad no implica cobertura completa.

Cada celda sí ejecutó 3.000 ofertas durante 60 s. La frase condicional contraria en el
`REPORT.md` sellado es un defecto de plantilla que se conserva para no mutar la evidencia.
